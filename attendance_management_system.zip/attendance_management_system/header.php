<?php
$main_url="http://localhost/attendance_management_system/";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Management System</title>
    <link rel="stylesheet" href="<?=$main_url?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?=$main_url?>assets/css/jquery-ui.css">
    <link rel="stylesheet" href="<?=$main_url?>assets/css/style.css">
    <script src="<?=$main_url?>assets/js/bootstrap.bundle.min.js"></script>
    <script src="<?=$main_url?>assets/js/jquery-3.7.1.js"></script>
    <script src="<?=$main_url?>assets/js/jquery-ui.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" />
</head>
<body>